import React, { createContext, useState, useCallback, ReactNode } from 'react';

export interface SearchParams {
  checkInDate: Date | undefined;
  checkOutDate: Date | undefined;
  rooms: number;
  adults: number;
  children: number;
  childrenAges: number[];
  district: string;
  roomType: string;
  starRating: string;
}

export interface RoomInfo {
  roomId: string;
  roomType: string;
  pricePerNight: number;
  quantity: number;
  amenities: string[];
  images: string[];
}

export interface GuestInfo {
  fullName: string;
  email: string;
  phone: string;
  gstNumber?: string;
  specialRequests?: string;
}

export interface SelectedRoom extends RoomInfo {
  numberOfNights: number;
  totalPrice: number;
}

export interface PricingInfo {
  basePrice: number;
  numberOfRooms: number;
  numberOfNights: number;
  subtotal: number;
  taxAmount: number;
  discountAmount: number;
  totalPrice: number;
}

export interface BookingInfo {
  hotelId: string;
  hotelName: string;
  hotelAddress: string;
  selectedRooms: SelectedRoom[];
  guestInfo: GuestInfo;
  pricing: PricingInfo;
  bookingReference?: string;
  bookingDate?: Date;
  status?: 'PENDING' | 'CONFIRMED' | 'CANCELLED';
}

export interface HotelBookingContextType {
  searchParams: SearchParams;
  setSearchParams: (params: Partial<SearchParams>) => void;
  selectedHotelId: string | null;
  setSelectedHotelId: (id: string | null) => void;
  bookingInfo: BookingInfo | null;
  setBookingInfo: (info: Partial<BookingInfo>) => void;
  currentStep: number;
  setCurrentStep: (step: number) => void;
  selectedRooms: SelectedRoom[];
  addSelectedRoom: (room: SelectedRoom) => void;
  removeSelectedRoom: (roomId: string) => void;
  updateSelectedRoom: (roomId: string, updates: Partial<SelectedRoom>) => void;
  guestInfo: GuestInfo;
  setGuestInfo: (info: Partial<GuestInfo>) => void;
  pricing: PricingInfo;
  calculatePricing: (basePrice: number, numberOfRooms: number, numberOfNights: number, discount?: number) => void;
  calculateNights: () => number;
  resetBooking: () => void;
  clearAllData: () => void;
}

const initialSearchParams: SearchParams = {
  checkInDate: undefined,
  checkOutDate: undefined,
  rooms: 1,
  adults: 1,
  children: 0,
  childrenAges: [],
  district: 'all',
  roomType: 'all',
  starRating: 'all',
};

const initialGuestInfo: GuestInfo = {
  fullName: '',
  email: '',
  phone: '',
  gstNumber: '',
  specialRequests: '',
};

const initialPricing: PricingInfo = {
  basePrice: 0,
  numberOfRooms: 0,
  numberOfNights: 0,
  subtotal: 0,
  taxAmount: 0,
  discountAmount: 0,
  totalPrice: 0,
};

const initialContextValue: HotelBookingContextType = {
  searchParams: initialSearchParams,
  setSearchParams: () => {},
  selectedHotelId: null,
  setSelectedHotelId: () => {},
  bookingInfo: null,
  setBookingInfo: () => {},
  currentStep: 0,
  setCurrentStep: () => {},
  selectedRooms: [],
  addSelectedRoom: () => {},
  removeSelectedRoom: () => {},
  updateSelectedRoom: () => {},
  guestInfo: initialGuestInfo,
  setGuestInfo: () => {},
  pricing: initialPricing,
  calculatePricing: () => {},
  calculateNights: () => 0,
  resetBooking: () => {},
  clearAllData: () => {},
};

export const HotelBookingContext = createContext<HotelBookingContextType>(initialContextValue);

interface HotelBookingProviderProps {
  children: ReactNode;
}

export const HotelBookingProvider: React.FC<HotelBookingProviderProps> = ({ children }) => {
  const [searchParams, setSearchParamsState] = useState<SearchParams>(initialSearchParams);
  const [selectedHotelId, setSelectedHotelId] = useState<string | null>(null);
  const [bookingInfo, setBookingInfoState] = useState<BookingInfo | null>(null);
  const [currentStep, setCurrentStep] = useState(0);
  const [selectedRooms, setSelectedRooms] = useState<SelectedRoom[]>([]);
  const [guestInfo, setGuestInfoState] = useState<GuestInfo>(initialGuestInfo);
  const [pricing, setPricingState] = useState<PricingInfo>(initialPricing);

  const setSearchParams = useCallback((params: Partial<SearchParams>) => {
    setSearchParamsState((prev) => ({ ...prev, ...params }));
  }, []);

  const addSelectedRoom = useCallback((room: SelectedRoom) => {
    setSelectedRooms((prev) => {
      const exists = prev.find((r) => r.roomId === room.roomId);
      if (exists) {
        return prev.map((r) =>
          r.roomId === room.roomId ? { ...r, quantity: r.quantity + room.quantity } : r
        );
      }
      return [...prev, room];
    });
  }, []);

  const removeSelectedRoom = useCallback((roomId: string) => {
    setSelectedRooms((prev) => prev.filter((r) => r.roomId !== roomId));
  }, []);

  const updateSelectedRoom = useCallback((roomId: string, updates: Partial<SelectedRoom>) => {
    setSelectedRooms((prev) =>
      prev.map((r) => (r.roomId === roomId ? { ...r, ...updates } : r))
    );
  }, []);

  const setGuestInfo = useCallback((info: Partial<GuestInfo>) => {
    setGuestInfoState((prev) => ({ ...prev, ...info }));
  }, []);

  const setBookingInfo = useCallback((info: Partial<BookingInfo>) => {
    setBookingInfoState((prev) => ({ ...prev, ...info } as BookingInfo));
  }, []);

  const calculateNights = useCallback((): number => {
    if (!searchParams.checkInDate || !searchParams.checkOutDate) return 0;
    const diffTime = Math.abs(searchParams.checkOutDate.getTime() - searchParams.checkInDate.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  }, [searchParams.checkInDate, searchParams.checkOutDate]);

  const calculatePricing = useCallback(
    (basePrice: number, numberOfRooms: number, numberOfNights: number, discount: number = 0) => {
      const subtotal = basePrice * numberOfRooms * numberOfNights;
      const taxAmount = Math.round(subtotal * 0.12);
      const discountAmount = discount > 0 ? Math.round(subtotal * (discount / 100)) : 0;
      const totalPrice = subtotal + taxAmount - discountAmount;

      setPricingState({ basePrice, numberOfRooms, numberOfNights, subtotal, taxAmount, discountAmount, totalPrice });
    },
    []
  );

  const resetBooking = useCallback(() => {
    setCurrentStep(0);
    setSelectedRooms([]);
    setGuestInfoState(initialGuestInfo);
    setPricingState(initialPricing);
  }, []);

  const clearAllData = useCallback(() => {
    setSearchParamsState(initialSearchParams);
    setSelectedHotelId(null);
    setBookingInfoState(null);
    setCurrentStep(0);
    setSelectedRooms([]);
    setGuestInfoState(initialGuestInfo);
    setPricingState(initialPricing);
  }, []);

  const value: HotelBookingContextType = {
    searchParams,
    setSearchParams,
    selectedHotelId,
    setSelectedHotelId,
    bookingInfo,
    setBookingInfo,
    currentStep,
    setCurrentStep,
    selectedRooms,
    addSelectedRoom,
    removeSelectedRoom,
    updateSelectedRoom,
    guestInfo,
    setGuestInfo,
    pricing,
    calculatePricing,
    calculateNights,
    resetBooking,
    clearAllData,
  };

  return (
    <HotelBookingContext.Provider value={value}>
      {children}
    </HotelBookingContext.Provider>
  );
};

export default HotelBookingProvider;
