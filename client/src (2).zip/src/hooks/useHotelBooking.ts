import { useContext } from 'react';
import { HotelBookingContext, HotelBookingContextType } from '../context/hotel-booking-context';

/**
 * Custom hook to use the HotelBookingContext
 * Throws error if used outside of HotelBookingProvider
 */
export const useHotelBooking = (): HotelBookingContextType => {
  const context = useContext(HotelBookingContext);

  if (!context) {
    throw new Error(
      'useHotelBooking must be used within a HotelBookingProvider. ' +
      'Wrap your component tree with <HotelBookingProvider> in your App.tsx or root component.'
    );
  }

  return context;
};

export default useHotelBooking;
