import React, { useState, useEffect } from 'react';
import { format } from 'date-fns';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Star, 
  MapPin, 
  Phone, 
  Mail, 
  Globe, 
  Wifi, 
  Users, 
  UtensilsCrossed,
  ChevronLeft,
  ChevronRight,
  Heart,
  Share2,
  AlertCircle
} from 'lucide-react';
import { useHotelBooking } from '@/hooks/useHotelBooking';
import axiosInstance from '@/axios/axios';

interface Hotel {
  id: string;
  displayName: string;
  legalName: string;
  city: string;
  district: string;
  state: string;
  landmark: string | null;
  description: string | null;
  starRating: number | null;
  hotelType: string | null;
  minTariff: number | null;
  roomTypeName: string | null;
  coverPhotoUrl: string | null;
}

interface HotelDetailModalProps {
  hotel: Hotel;
  onClose: () => void;
}

const HotelDetailModal: React.FC<HotelDetailModalProps> = ({ hotel, onClose }) => {
  const navigate = useNavigate();
  const { searchParams, setSelectedHotelId, setCurrentStep } = useHotelBooking();
  const [activeImageIndex, setActiveImageIndex] = useState(0);
  const [hotelImages, setHotelImages] = useState<string[]>([]);
  const [hotelDetails, setHotelDetails] = useState<any>(null);
  const [isAvailable, setIsAvailable] = useState(true);
  const [availableRooms, setAvailableRooms] = useState(0);
  const [loading, setLoading] = useState(true);
  const [isFavorite, setIsFavorite] = useState(false);

  // Fetch detailed hotel information
  useEffect(() => {
    const fetchHotelDetails = async () => {
      try {
        setLoading(true);
        
        // Fetch hotel details
        const detailsResponse = await axiosInstance.get(`/api/hotel/${hotel.id}`);
        setHotelDetails(detailsResponse.data);

        // Fetch hotel images/gallery
        try {
          const imagesResponse = await axiosInstance.get(`/api/hotel/${hotel.id}/images`);
          if (imagesResponse.data && Array.isArray(imagesResponse.data)) {
            setHotelImages(imagesResponse.data.map((img: any) => img.imageUrl || img.url));
          }
        } catch (err) {
          console.error('Error fetching images:', err);
          setHotelImages([]);
        }

        // Check availability
        if (searchParams.checkInDate && searchParams.checkOutDate) {
          try {
            const availResponse = await axiosInstance.get(
              `/api/hotel/${hotel.id}/availability`,
              {
                params: {
                  checkIn: format(searchParams.checkInDate, 'yyyy-MM-dd'),
                  checkOut: format(searchParams.checkOutDate, 'yyyy-MM-dd'),
                },
              }
            );
            setIsAvailable(availResponse.data.available);
            setAvailableRooms(availResponse.data.availableRooms || 0);
          } catch (err) {
            console.error('Error checking availability:', err);
            setIsAvailable(true);
          }
        }
      } catch (error) {
        console.error('Error fetching hotel details:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchHotelDetails();
  }, [hotel.id, searchParams.checkInDate, searchParams.checkOutDate]);

  // Handle booking button click
  const handleBookNow = () => {
    setSelectedHotelId(hotel.id);
    setCurrentStep(1); // Go to room selection step
    navigate(`/booking/${hotel.id}`);
    onClose();
  };

  // Handle next/previous image
  const handleNextImage = () => {
    if (hotelImages.length > 0) {
      setActiveImageIndex((prev) => (prev + 1) % hotelImages.length);
    }
  };

  const handlePrevImage = () => {
    if (hotelImages.length > 0) {
      setActiveImageIndex((prev) => (prev - 1 + hotelImages.length) % hotelImages.length);
    }
  };

  // Get current image
  const currentImage = hotelImages.length > 0 
    ? hotelImages[activeImageIndex] 
    : hotel.coverPhotoUrl;

  // Render star rating
  const renderStars = (rating: number | null) => {
    if (!rating) return null;
    return (
      <div className="flex gap-1">
        {Array.from({ length: Math.floor(rating) }).map((_, i) => (
          <Star key={i} size={16} className="fill-yellow-400 text-yellow-400" />
        ))}
        {rating % 1 > 0 && (
          <Star size={16} className="fill-yellow-200 text-yellow-400" />
        )}
      </div>
    );
  };

  // Format phone number
  const formatPhoneNumber = (phone: string | null) => {
    if (!phone) return 'Not available';
    return phone;
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  const nights = searchParams.checkInDate && searchParams.checkOutDate
    ? Math.ceil((searchParams.checkOutDate.getTime() - searchParams.checkInDate.getTime()) / (1000 * 60 * 60 * 24))
    : 0;

  const totalPrice = hotel.minTariff ? hotel.minTariff * searchParams.rooms * nights : 0;

  return (
    <div className="w-full bg-white rounded-lg">
      {/* Header */}
      <div className="sticky top-0 z-10 bg-white border-b px-6 py-4 flex justify-between items-start">
        <div>
          <h2 className="text-2xl font-bold">{hotel.displayName || hotel.legalName}</h2>
          <div className="flex items-center gap-2 mt-2 flex-wrap">
            {renderStars(hotel.starRating)}
            {hotel.hotelType && <Badge variant="secondary">{hotel.hotelType}</Badge>}
          </div>
        </div>
        <div className="flex gap-2">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setIsFavorite(!isFavorite)}
            className={isFavorite ? 'text-red-500' : ''}
          >
            <Heart size={20} fill={isFavorite ? 'currentColor' : 'none'} />
          </Button>
          <Button variant="ghost" size="icon">
            <Share2 size={20} />
          </Button>
        </div>
      </div>

      {/* Content */}
      <div className="px-6 py-6 space-y-6">
        {/* Image Gallery */}
        <div className="relative">
          <div className="relative w-full h-80 bg-gray-200 rounded-lg overflow-hidden">
            <img
              src={currentImage || `${import.meta.env.VITE_BASE}assets/images/hotel-booking/gallery-1.jpeg`}
              alt="Hotel"
              className="w-full h-full object-cover"
              onError={(e) => {
                (e.target as HTMLImageElement).src =
                  `${import.meta.env.VITE_BASE}assets/images/hotel-booking/gallery-1.jpeg`;
              }}
            />
            {hotelImages.length > 1 && (
              <>
                <Button
                  variant="ghost"
                  size="icon"
                  className="absolute left-2 top-1/2 -translate-y-1/2 bg-white/80 hover:bg-white"
                  onClick={handlePrevImage}
                >
                  <ChevronLeft size={24} />
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  className="absolute right-2 top-1/2 -translate-y-1/2 bg-white/80 hover:bg-white"
                  onClick={handleNextImage}
                >
                  <ChevronRight size={24} />
                </Button>
              </>
            )}
            <div className="absolute bottom-4 right-4 bg-black/70 text-white px-3 py-1 rounded text-sm">
              {activeImageIndex + 1} / {hotelImages.length || 1}
            </div>
          </div>
        </div>

        {/* Location & Contact */}
        <Card>
          <CardContent className="pt-6 space-y-4">
            <div className="flex gap-3">
              <MapPin className="text-red-500 flex-shrink-0" />
              <div>
                <p className="font-semibold">Location</p>
                <p className="text-sm text-gray-600">
                  {[hotel.city, hotel.district, hotel.state].filter(Boolean).join(', ')}
                </p>
                {hotel.landmark && (
                  <p className="text-sm text-gray-500">Near {hotel.landmark}</p>
                )}
              </div>
            </div>
            <div className="border-t pt-4 flex gap-3">
              <Phone className="text-blue-500 flex-shrink-0" />
              <div>
                <p className="font-semibold">Contact</p>
                <p className="text-sm">{formatPhoneNumber(hotelDetails?.phone)}</p>
              </div>
            </div>
            {hotelDetails?.email && (
              <div className="border-t pt-4 flex gap-3">
                <Mail className="text-green-500 flex-shrink-0" />
                <div>
                  <p className="font-semibold">Email</p>
                  <p className="text-sm">{hotelDetails.email}</p>
                </div>
              </div>
            )}
            {hotelDetails?.website && (
              <div className="border-t pt-4 flex gap-3">
                <Globe className="text-purple-500 flex-shrink-0" />
                <div>
                  <p className="font-semibold">Website</p>
                  <a href={hotelDetails.website} target="_blank" rel="noopener noreferrer" className="text-sm text-blue-600 hover:underline">
                    {hotelDetails.website}
                  </a>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* About */}
        {hotel.description && (
          <Card>
            <CardContent className="pt-6">
              <p className="font-semibold mb-3">About</p>
              <p className="text-sm text-gray-700 leading-relaxed">{hotel.description}</p>
            </CardContent>
          </Card>
        )}

        {/* Amenities & Features */}
        <Tabs defaultValue="amenities" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="amenities">Amenities</TabsTrigger>
            <TabsTrigger value="rooms">Rooms</TabsTrigger>
          </TabsList>
          
          <TabsContent value="amenities" className="mt-4">
            <Card>
              <CardContent className="pt-6">
                <div className="grid grid-cols-2 gap-4">
                  <div className="flex gap-2">
                    <Wifi size={20} className="text-primary flex-shrink-0" />
                    <span className="text-sm">Free WiFi</span>
                  </div>
                  <div className="flex gap-2">
                    <UtensilsCrossed size={20} className="text-primary flex-shrink-0" />
                    <span className="text-sm">Restaurant</span>
                  </div>
                  <div className="flex gap-2">
                    <Users size={20} className="text-primary flex-shrink-0" />
                    <span className="text-sm">Conference Rooms</span>
                  </div>
                  <div className="flex gap-2">
                    <span className="text-sm">24x7 Service</span>
                  </div>
                </div>
                {hotelDetails?.amenities && hotelDetails.amenities.length > 0 && (
                  <>
                    <div className="border-t my-4"></div>
                    <div className="space-y-2">
                      {hotelDetails.amenities.map((amenity: string, idx: number) => (
                        <p key={idx} className="text-sm">✓ {amenity}</p>
                      ))}
                    </div>
                  </>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="rooms" className="mt-4">
            <Card>
              <CardContent className="pt-6">
                <p className="text-sm font-semibold mb-3">{hotel.roomTypeName || 'Standard Rooms'}</p>
                <p className="text-sm text-gray-600">
                  Various room types available with modern amenities
                </p>
                {hotelDetails?.roomTypes && hotelDetails.roomTypes.length > 0 && (
                  <div className="mt-4 space-y-3">
                    {hotelDetails.roomTypes.map((room: any, idx: number) => (
                      <div key={idx} className="p-3 bg-gray-50 rounded">
                        <p className="font-semibold text-sm">{room.name}</p>
                        <p className="text-xs text-gray-600">{room.capacity} guests</p>
                        <p className="text-sm font-semibold mt-2">₹{room.price?.toLocaleString('en-IN')}/night</p>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Availability & Booking */}
        <Card className={!isAvailable ? 'border-red-200 bg-red-50' : ''}>
          <CardContent className="pt-6">
            <div className="space-y-4">
              {searchParams.checkInDate && searchParams.checkOutDate && (
                <>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <p className="text-gray-600">Check-in</p>
                      <p className="font-semibold">{format(searchParams.checkInDate, 'MMM dd, yyyy')}</p>
                    </div>
                    <div>
                      <p className="text-gray-600">Check-out</p>
                      <p className="font-semibold">{format(searchParams.checkOutDate, 'MMM dd, yyyy')}</p>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <p className="text-gray-600">Rooms</p>
                      <p className="font-semibold">{searchParams.rooms} room(s)</p>
                    </div>
                    <div>
                      <p className="text-gray-600">Guests</p>
                      <p className="font-semibold">
                        {searchParams.adults} adult(s)
                        {searchParams.children > 0 && `, ${searchParams.children} child(ren)`}
                      </p>
                    </div>
                  </div>
                </>
              )}

              {!isAvailable && (
                <div className="flex gap-2 p-3 bg-red-100 border border-red-300 rounded text-sm text-red-700">
                  <AlertCircle size={18} className="flex-shrink-0" />
                  <span>No rooms available for the selected dates</span>
                </div>
              )}

              {isAvailable && availableRooms <= 3 && (
                <div className="flex gap-2 p-3 bg-orange-100 border border-orange-300 rounded text-sm text-orange-700">
                  <AlertCircle size={18} className="flex-shrink-0" />
                  <span>Only {availableRooms} room(s) left - Book soon!</span>
                </div>
              )}

              {hotel.minTariff && nights > 0 && (
                <>
                  <div className="border-t pt-4">
                    <div className="flex justify-between items-center">
                      <span className="text-gray-600">Price per room per night:</span>
                      <span className="font-semibold">₹{hotel.minTariff.toLocaleString('en-IN')}</span>
                    </div>
                    <div className="flex justify-between items-center text-sm text-gray-600 mt-2">
                      <span>{searchParams.rooms} room(s) × {nights} night(s)</span>
                    </div>
                    <div className="border-t my-3"></div>
                    <div className="flex justify-between items-center text-lg font-bold">
                      <span>Total Price:</span>
                      <span className="text-primary">
                        ₹{(totalPrice * 1.12).toLocaleString('en-IN', {
                          minimumFractionDigits: 0,
                          maximumFractionDigits: 0,
                        })}
                      </span>
                    </div>
                    <p className="text-xs text-gray-500 mt-2">Includes 12% GST & taxes</p>
                  </div>
                </>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Action Buttons */}
        <div className="flex gap-3 pb-6">
          {isAvailable ? (
            <>
              <Button variant="outline" className="flex-1" onClick={onClose}>
                Continue Browsing
              </Button>
              <Button className="flex-1" onClick={handleBookNow}>
                Book Now
              </Button>
            </>
          ) : (
            <>
              <Button variant="outline" className="flex-1" onClick={onClose}>
                Back
              </Button>
              <Button disabled className="flex-1 bg-gray-400">
                Sold Out
              </Button>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default HotelDetailModal;
