import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useHotelBooking } from '@/hooks/useHotelBooking';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ChevronRight, ChevronLeft } from 'lucide-react';

// Step components - Create these files separately
import RoomSelection from './RoomSelection';
import GuestDetails from './GuestDetails';
import PricingSummary from './PricingSummary';
import BookingConfirmation from './BookingConfirmation';

interface BookingStep {
  id: number;
  title: string;
  description: string;
}

const BOOKING_STEPS: BookingStep[] = [
  { id: 1, title: 'Select Rooms', description: 'Choose your rooms' },
  { id: 2, title: 'Guest Details', description: 'Provide your information' },
  { id: 3, title: 'Review & Pay', description: 'Check pricing and book' },
  { id: 4, title: 'Confirmation', description: 'Your booking is confirmed' },
];

const BookingLayout: React.FC = () => {
  const { hotelId } = useParams<{ hotelId: string }>();
  const navigate = useNavigate();
  const { currentStep, setCurrentStep, selectedRooms, guestInfo } = useHotelBooking();
  const [loading, setLoading] = useState(false);

  // Validate step progression
  const canProceedToNextStep = (): boolean => {
    switch (currentStep) {
      case 0: // Room selection
        return selectedRooms.length > 0;
      case 1: // Guest details
        return guestInfo.fullName.trim() !== '' && guestInfo.email.trim() !== '' && guestInfo.phone.trim() !== '';
      case 2: // Review
        return true; // Can always review
      case 3: // Confirmation
        return true;
      default:
        return false;
    }
  };

  const handleNextStep = async () => {
    if (!canProceedToNextStep()) {
      alert('Please complete the current step before proceeding');
      return;
    }

    if (currentStep < 3) {
      setCurrentStep(currentStep + 1);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const handlePrevStep = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const handleCancel = () => {
    const confirmed = window.confirm('Are you sure you want to cancel this booking?');
    if (confirmed) {
      navigate('/hotel-list');
    }
  };

  if (!hotelId) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <p className="text-red-500">Invalid hotel selection</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Complete Your Booking</h1>
          <p className="text-gray-600">Step {currentStep + 1} of 4</p>
        </div>

        {/* Stepper */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            {BOOKING_STEPS.map((step, index) => (
              <React.Fragment key={step.id}>
                <div
                  className={`flex flex-col items-center cursor-pointer transition-all ${
                    index <= currentStep ? 'opacity-100' : 'opacity-50'
                  }`}
                  onClick={() => {
                    if (index < currentStep) {
                      setCurrentStep(index);
                    }
                  }}
                >
                  <div
                    className={`w-10 h-10 rounded-full flex items-center justify-center font-semibold transition-all ${
                      index === currentStep
                        ? 'bg-blue-600 text-white ring-2 ring-blue-300'
                        : index < currentStep
                        ? 'bg-green-500 text-white'
                        : 'bg-gray-200 text-gray-600'
                    }`}
                  >
                    {index < currentStep ? '✓' : index + 1}
                  </div>
                  <div className="text-sm font-semibold mt-2 text-center max-w-24">
                    {step.title}
                  </div>
                  <div className="text-xs text-gray-500 text-center max-w-24">
                    {step.description}
                  </div>
                </div>

                {index < BOOKING_STEPS.length - 1 && (
                  <div
                    className={`flex-1 h-1 mx-2 mb-6 transition-all ${
                      index < currentStep ? 'bg-green-500' : 'bg-gray-200'
                    }`}
                  ></div>
                )}
              </React.Fragment>
            ))}
          </div>
        </div>

        {/* Main Content */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Column - Step Content */}
          <div className="lg:col-span-2">
            <Card>
              <CardContent className="p-8">
                {currentStep === 0 && <RoomSelection hotelId={hotelId} />}
                {currentStep === 1 && <GuestDetails />}
                {currentStep === 2 && <PricingSummary hotelId={hotelId} />}
                {currentStep === 3 && <BookingConfirmation hotelId={hotelId} />}
              </CardContent>
            </Card>

            {/* Navigation Buttons */}
            {currentStep < 3 && (
              <div className="flex gap-4 mt-6 justify-between">
                <Button
                  variant="outline"
                  onClick={handlePrevStep}
                  disabled={currentStep === 0 || loading}
                  className="flex items-center gap-2"
                >
                  <ChevronLeft size={20} />
                  {currentStep === 0 ? 'Cancel' : 'Back'}
                </Button>

                <Button
                  onClick={currentStep === 0 ? handleCancel : handleNextStep}
                  disabled={!canProceedToNextStep() || loading}
                  className="flex items-center gap-2"
                  size="lg"
                >
                  {currentStep === 0 ? 'Cancel Booking' : 'Continue'}
                  {currentStep !== 0 && <ChevronRight size={20} />}
                </Button>
              </div>
            )}
          </div>

          {/* Right Column - Sidebar */}
          <div className="lg:col-span-1">
            <Card className="sticky top-20">
              <CardHeader>
                <CardTitle className="text-lg">Booking Summary</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Hotel Info */}
                <div className="pb-4 border-b">
                  <p className="text-sm text-gray-600">Hotel</p>
                  <p className="font-semibold">Loading Hotel Details...</p>
                </div>

                {/* Room Info */}
                {selectedRooms.length > 0 && (
                  <div className="pb-4 border-b">
                    <p className="text-sm text-gray-600 mb-2">Rooms</p>
                    {selectedRooms.map((room) => (
                      <div key={room.roomId} className="flex justify-between text-sm mb-1">
                        <span>{room.quantity}x {room.roomType}</span>
                        <span className="font-semibold">
                          ₹{(room.totalPrice).toLocaleString('en-IN')}
                        </span>
                      </div>
                    ))}
                  </div>
                )}

                {/* Guest Info */}
                {guestInfo.fullName && (
                  <div className="pb-4 border-b">
                    <p className="text-sm text-gray-600">Guest Name</p>
                    <p className="font-semibold text-sm">{guestInfo.fullName}</p>
                  </div>
                )}

                {/* Price Summary */}
                <div className="space-y-2 pt-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Subtotal</span>
                    <span>Loading...</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Taxes (12%)</span>
                    <span>Loading...</span>
                  </div>
                  <div className="flex justify-between font-bold text-lg pt-2 border-t">
                    <span>Total</span>
                    <span className="text-blue-600">Loading...</span>
                  </div>
                </div>

                {/* Help */}
                <div className="mt-6 pt-6 border-t space-y-3">
                  <p className="text-xs text-gray-600">Questions?</p>
                  <Button variant="outline" className="w-full text-xs" size="sm">
                    📞 Call Us
                  </Button>
                  <Button variant="outline" className="w-full text-xs" size="sm">
                    💬 Chat Support
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Important Info */}
        <Card className="mt-8 bg-blue-50 border-blue-200">
          <CardContent className="p-6">
            <h3 className="font-semibold mb-2">Important Information</h3>
            <ul className="text-sm text-gray-700 space-y-1">
              <li>• You can modify or cancel your booking up to 24 hours before check-in</li>
              <li>• A confirmation email will be sent to your registered email address</li>
              <li>• Check-in time is usually 2:00 PM and check-out is 11:00 AM</li>
              <li>• Please carry a valid ID at the time of check-in</li>
            </ul>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default BookingLayout;
