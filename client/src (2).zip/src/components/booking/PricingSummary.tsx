import React, { useEffect, useState } from 'react';
import { format } from 'date-fns';
import { useHotelBooking } from '@/hooks/useHotelBooking';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { AlertCircle, MapPin } from 'lucide-react';
import axiosInstance from '@/axios/axios';

interface PricingSummaryProps {
  hotelId: string;
}

const PricingSummary: React.FC<PricingSummaryProps> = ({ hotelId }) => {
  const { searchParams, selectedRooms, guestInfo, calculatePricing, calculateNights, pricing } = useHotelBooking();
  const [hotelName, setHotelName] = useState<string>('');
  const [hotelLocation, setHotelLocation] = useState<string>('');
  const [loading, setLoading] = useState(true);

  const nights = calculateNights();

  // Fetch hotel details
  useEffect(() => {
    const fetchHotelDetails = async () => {
      try {
        const response = await axiosInstance.get(`/api/hotel/${hotelId}`);
        setHotelName(response.data.displayName || response.data.legalName);
        setHotelLocation(
          `${response.data.city}, ${response.data.district}, ${response.data.state}`
        );
      } catch (error) {
        console.error('Error fetching hotel details:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchHotelDetails();
  }, [hotelId]);

  // Calculate pricing
  useEffect(() => {
    const totalBasePrice = selectedRooms.reduce((sum, room) => sum + room.pricePerNight, 0);
    const totalRooms = selectedRooms.reduce((sum, room) => sum + room.quantity, 0);
    
    calculatePricing(totalBasePrice, totalRooms, nights);
  }, [selectedRooms, nights, calculatePricing]);

  // Calculate price per room breakdown
  const getRoomBreakdown = () => {
    return selectedRooms.map((room) => ({
      roomType: room.roomType,
      quantity: room.quantity,
      pricePerNight: room.pricePerNight,
      nights,
      subtotal: room.pricePerNight * room.quantity * nights,
    }));
  };

  const roomBreakdown = getRoomBreakdown();

  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-bold mb-2">Review & Payment</h2>
        <p className="text-gray-600">Review your booking details before confirming</p>
      </div>

      {/* Hotel Details */}
      {!loading && (
        <Card>
          <CardContent className="p-6">
            <h3 className="font-bold text-lg mb-4">Booking Summary</h3>
            <div className="space-y-3">
              <div>
                <p className="text-gray-600 text-sm">Hotel</p>
                <p className="font-semibold text-lg">{hotelName}</p>
              </div>
              <div className="flex items-start gap-2">
                <MapPin size={18} className="text-red-500 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="text-gray-600 text-sm">Location</p>
                  <p className="font-semibold">{hotelLocation}</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Stay Details */}
      <Card>
        <CardContent className="p-6">
          <h3 className="font-bold text-lg mb-4">Stay Details</h3>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <p className="text-gray-600 text-sm">Check-in</p>
              <p className="font-semibold">{format(searchParams.checkInDate!, 'MMM dd, yyyy')}</p>
              <p className="text-xs text-gray-500">2:00 PM onwards</p>
            </div>
            <div>
              <p className="text-gray-600 text-sm">Check-out</p>
              <p className="font-semibold">{format(searchParams.checkOutDate!, 'MMM dd, yyyy')}</p>
              <p className="text-xs text-gray-500">11:00 AM</p>
            </div>
            <div>
              <p className="text-gray-600 text-sm">Duration</p>
              <p className="font-semibold">{nights} night(s)</p>
            </div>
            <div>
              <p className="text-gray-600 text-sm">Guests</p>
              <p className="font-semibold">
                {searchParams.adults} adult(s)
                {searchParams.children > 0 && ` + ${searchParams.children} child(ren)`}
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Rooms Booked */}
      <Card>
        <CardContent className="p-6">
          <h3 className="font-bold text-lg mb-4">Rooms Booked</h3>
          <div className="space-y-4">
            {roomBreakdown.map((room, idx) => (
              <div key={idx} className="pb-4 border-b last:border-b-0 last:pb-0">
                <div className="flex justify-between items-start mb-3">
                  <div>
                    <p className="font-semibold text-lg">{room.roomType}</p>
                    <p className="text-sm text-gray-600">
                      {room.quantity} room{room.quantity > 1 ? 's' : ''} × {room.nights} night{room.nights > 1 ? 's' : ''}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold text-lg">
                      ₹{room.subtotal.toLocaleString('en-IN')}
                    </p>
                    <p className="text-xs text-gray-600">
                      ₹{room.pricePerNight.toLocaleString('en-IN')}/night
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Guest Info Confirmation */}
      <Card>
        <CardContent className="p-6">
          <h3 className="font-bold text-lg mb-4">Guest Information</h3>
          <div className="space-y-3">
            <div>
              <p className="text-gray-600 text-sm">Name</p>
              <p className="font-semibold">{guestInfo.fullName}</p>
            </div>
            <div>
              <p className="text-gray-600 text-sm">Email</p>
              <p className="font-semibold">{guestInfo.email}</p>
            </div>
            <div>
              <p className="text-gray-600 text-sm">Phone</p>
              <p className="font-semibold">{guestInfo.phone}</p>
            </div>
            {guestInfo.gstNumber && (
              <div>
                <p className="text-gray-600 text-sm">GST Number</p>
                <p className="font-semibold">{guestInfo.gstNumber}</p>
              </div>
            )}
            {guestInfo.specialRequests && (
              <div>
                <p className="text-gray-600 text-sm">Special Requests</p>
                <p className="font-semibold">{guestInfo.specialRequests}</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Pricing Breakdown */}
      <Card className="border-2 border-blue-200 bg-blue-50">
        <CardContent className="p-8">
          <h3 className="font-bold text-lg mb-6">Price Breakdown</h3>
          <div className="space-y-4">
            {/* Subtotal */}
            <div className="flex justify-between items-center">
              <span className="text-gray-700">Rooms ({nights} night{nights > 1 ? 's' : ''})</span>
              <span className="font-semibold">
                ₹{pricing.subtotal.toLocaleString('en-IN')}
              </span>
            </div>

            {/* Breakdown per room type */}
            {roomBreakdown.length > 1 && (
              <div className="pl-4 space-y-2 text-sm text-gray-600 border-l-2 border-gray-300">
                {roomBreakdown.map((room, idx) => (
                  <div key={idx} className="flex justify-between">
                    <span>
                      {room.quantity}x {room.roomType} ({room.nights} night{room.nights > 1 ? 's' : ''})
                    </span>
                    <span>₹{room.subtotal.toLocaleString('en-IN')}</span>
                  </div>
                ))}
              </div>
            )}

            {/* Taxes */}
            <div className="border-t pt-4 flex justify-between items-center">
              <span className="text-gray-700">
                Taxes & Charges (12% GST)
                <br />
                <span className="text-xs text-gray-600">
                  ₹{pricing.subtotal.toLocaleString('en-IN')} × 12%
                </span>
              </span>
              <span className="font-semibold">
                ₹{pricing.taxAmount.toLocaleString('en-IN')}
              </span>
            </div>

            {/* Discount if any */}
            {pricing.discountAmount > 0 && (
              <div className="flex justify-between items-center text-green-600">
                <span>Discount</span>
                <span className="font-semibold">
                  -₹{pricing.discountAmount.toLocaleString('en-IN')}
                </span>
              </div>
            )}

            {/* Total */}
            <div className="border-t-2 border-blue-300 pt-4 flex justify-between items-center">
              <span className="text-lg font-bold text-blue-900">Total Price</span>
              <span className="text-3xl font-bold text-blue-600">
                ₹{pricing.totalPrice.toLocaleString('en-IN')}
              </span>
            </div>

            {/* Per Night Average */}
            <div className="text-right text-xs text-gray-600">
              ₹{Math.round(pricing.totalPrice / nights).toLocaleString('en-IN')} per night on average
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Important Information */}
      <Card className="bg-orange-50 border-orange-200">
        <CardContent className="p-6 space-y-3">
          <h3 className="font-bold text-orange-900 flex items-center gap-2">
            <AlertCircle size={20} className="text-orange-600" />
            Cancellation & Policies
          </h3>
          <div className="text-sm text-orange-900 space-y-2">
            <div className="flex gap-2">
              <span className="flex-shrink-0">•</span>
              <span>Free cancellation until 24 hours before check-in</span>
            </div>
            <div className="flex gap-2">
              <span className="flex-shrink-0">•</span>
              <span>Cancellation within 24 hours will incur full charges</span>
            </div>
            <div className="flex gap-2">
              <span className="flex-shrink-0">•</span>
              <span>Check-in is after 2:00 PM and check-out is by 11:00 AM</span>
            </div>
            <div className="flex gap-2">
              <span className="flex-shrink-0">•</span>
              <span>Valid ID is mandatory at the time of check-in</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Payment Methods Info */}
      <Card>
        <CardContent className="p-6">
          <h3 className="font-bold text-lg mb-4">Accepted Payment Methods</h3>
          <div className="grid grid-cols-2 gap-4">
            <Badge className="p-3 text-center justify-center bg-blue-100 text-blue-900">
              Credit Card
            </Badge>
            <Badge className="p-3 text-center justify-center bg-green-100 text-green-900">
              Debit Card
            </Badge>
            <Badge className="p-3 text-center justify-center bg-purple-100 text-purple-900">
              UPI/Net Banking
            </Badge>
            <Badge className="p-3 text-center justify-center bg-orange-100 text-orange-900">
              Wallet
            </Badge>
          </div>
        </CardContent>
      </Card>

      {/* Terms Confirmation */}
      <Card className="bg-green-50 border-green-200">
        <CardContent className="p-6">
          <p className="text-sm text-green-900">
            ✓ By proceeding with payment, you agree to the terms, conditions, and cancellation policy.
          </p>
        </CardContent>
      </Card>
    </div>
  );
};

export default PricingSummary;
