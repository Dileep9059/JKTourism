import React, { useState, useEffect } from 'react';
import { format } from 'date-fns';
import { useNavigate } from 'react-router-dom';
import { useHotelBooking } from '@/hooks/useHotelBooking';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  CheckCircle,
  MapPin,
  Calendar,
  Users,
  Phone,
  Mail,
  Download,
  Share2,
  ArrowRight,
} from 'lucide-react';
import axiosInstance from '@/axios/axios';

interface BookingConfirmationProps {
  hotelId: string;
}

const BookingConfirmation: React.FC<BookingConfirmationProps> = ({ hotelId }) => {
  const navigate = useNavigate();
  const { searchParams, selectedRooms, guestInfo, pricing } = useHotelBooking();
  const [bookingReference, setBookingReference] = useState<string>('');
  const [hotelDetails, setHotelDetails] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  // Generate booking reference and fetch hotel details
  useEffect(() => {
    const generateReference = () => {
      // Format: BK-YYYYMMDD-XXXXX
      const date = new Date();
      const dateStr = format(date, 'yyyyMMdd');
      const random = Math.floor(Math.random() * 99999)
        .toString()
        .padStart(5, '0');
      return `BK-${dateStr}-${random}`;
    };

    const fetchHotelDetails = async () => {
      try {
        const response = await axiosInstance.get(`/api/hotel/${hotelId}`);
        setHotelDetails(response.data);
        setBookingReference(generateReference());
      } catch (error) {
        console.error('Error fetching hotel details:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchHotelDetails();
  }, [hotelId]);

  const handleDownloadReceipt = () => {
    // Create a simple PDF-like download
    const receiptContent = `
BOOKING CONFIRMATION RECEIPT

Booking Reference: ${bookingReference}
Booking Date: ${format(new Date(), 'MMM dd, yyyy HH:mm')}

═══════════════════════════════════════════════════════

HOTEL DETAILS
Hotel Name: ${hotelDetails?.displayName || hotelDetails?.legalName}
Address: ${hotelDetails?.city}, ${hotelDetails?.district}, ${hotelDetails?.state}

═══════════════════════════════════════════════════════

STAY DETAILS
Check-in: ${format(searchParams.checkInDate!, 'MMM dd, yyyy')} (2:00 PM)
Check-out: ${format(searchParams.checkOutDate!, 'MMM dd, yyyy')} (11:00 AM)
Number of Nights: ${Math.ceil(
      (searchParams.checkOutDate!.getTime() - searchParams.checkInDate!.getTime()) /
        (1000 * 60 * 60 * 24)
    )}

═══════════════════════════════════════════════════════

GUEST INFORMATION
Name: ${guestInfo.fullName}
Email: ${guestInfo.email}
Phone: ${guestInfo.phone}
${guestInfo.gstNumber ? `GST Number: ${guestInfo.gstNumber}` : ''}

═══════════════════════════════════════════════════════

ROOMS BOOKED
${selectedRooms
  .map(
    (room) =>
      `${room.quantity}x ${room.roomType} - ₹${(room.totalPrice).toLocaleString('en-IN')}`
  )
  .join('\n')}

═══════════════════════════════════════════════════════

PRICE SUMMARY
Subtotal: ₹${pricing.subtotal.toLocaleString('en-IN')}
Taxes (12% GST): ₹${pricing.taxAmount.toLocaleString('en-IN')}
${pricing.discountAmount > 0 ? `Discount: -₹${pricing.discountAmount.toLocaleString('en-IN')}` : ''}
─────────────────────────────────
TOTAL AMOUNT: ₹${pricing.totalPrice.toLocaleString('en-IN')}

═══════════════════════════════════════════════════════

IMPORTANT INFORMATION
• Please arrive by 11:00 PM for smooth check-in
• A valid government-issued ID is required at check-in
• Free cancellation available until 24 hours before check-in
• Contact the hotel directly for any changes or special requests

HOTEL CONTACT
Phone: ${hotelDetails?.phone || 'Contact during booking'}
Email: ${hotelDetails?.email || 'Contact during booking'}

═══════════════════════════════════════════════════════

Thank you for booking with us!
We hope you have a wonderful stay.

This is a digital confirmation. Please keep it for your reference.
`;

    const element = document.createElement('a');
    element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(receiptContent));
    element.setAttribute('download', `Booking_${bookingReference}.txt`);
    element.style.display = 'none';
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  const handleShareBooking = () => {
    const shareText = `I just booked a hotel! Booking Reference: ${bookingReference}. Check your confirmation email for details.`;
    
    if (navigator.share) {
      navigator.share({
        title: 'Booking Confirmation',
        text: shareText,
      });
    } else {
      // Fallback: Copy to clipboard
      navigator.clipboard.writeText(
        `Booking Reference: ${bookingReference}\nBooking Details: ${window.location.href}`
      );
      alert('Booking reference copied to clipboard!');
    }
  };

  const nights = Math.ceil(
    (searchParams.checkOutDate!.getTime() - searchParams.checkInDate!.getTime()) /
      (1000 * 60 * 60 * 24)
  );

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Success Message */}
      <div className="text-center space-y-4 py-8">
        <CheckCircle size={64} className="mx-auto text-green-500" />
        <div>
          <h2 className="text-3xl font-bold text-green-700 mb-2">Booking Confirmed!</h2>
          <p className="text-gray-600 text-lg">
            Your booking has been successfully confirmed
          </p>
        </div>
      </div>

      {/* Booking Reference */}
      <Card className="bg-gradient-to-r from-blue-50 to-blue-100 border-blue-200">
        <CardContent className="p-8">
          <p className="text-gray-700 text-sm mb-3">Booking Reference Number</p>
          <div className="bg-white p-4 rounded-lg border-2 border-blue-400">
            <p className="text-2xl font-mono font-bold text-blue-600 text-center">
              {bookingReference}
            </p>
          </div>
          <p className="text-xs text-gray-600 mt-3 text-center">
            Save this reference number for your records and check-in
          </p>
        </CardContent>
      </Card>

      {/* Hotel Details */}
      {hotelDetails && (
        <Card>
          <CardContent className="p-8">
            <h3 className="font-bold text-lg mb-6">Hotel Details</h3>
            <div className="space-y-4">
              <div>
                <p className="text-gray-600 text-sm">Hotel Name</p>
                <p className="font-semibold text-xl">{hotelDetails.displayName || hotelDetails.legalName}</p>
              </div>
              <div className="flex items-start gap-3">
                <MapPin size={20} className="text-red-500 flex-shrink-0 mt-1" />
                <div>
                  <p className="text-gray-600 text-sm">Address</p>
                  <p className="font-semibold">
                    {hotelDetails.address || `${hotelDetails.city}, ${hotelDetails.district}, ${hotelDetails.state}`}
                  </p>
                  {hotelDetails.landmark && (
                    <p className="text-sm text-gray-600">Near {hotelDetails.landmark}</p>
                  )}
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4 pt-4 border-t">
                <div className="flex items-start gap-2">
                  <Phone size={18} className="text-blue-500 flex-shrink-0 mt-1" />
                  <div>
                    <p className="text-gray-600 text-xs">Phone</p>
                    <p className="font-semibold text-sm">{hotelDetails.phone || 'Contact via email'}</p>
                  </div>
                </div>
                <div className="flex items-start gap-2">
                  <Mail size={18} className="text-green-500 flex-shrink-0 mt-1" />
                  <div>
                    <p className="text-gray-600 text-xs">Email</p>
                    <p className="font-semibold text-sm">{hotelDetails.email || 'Not available'}</p>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Stay & Guest Summary */}
      <Card>
        <CardContent className="p-8">
          <h3 className="font-bold text-lg mb-6">Stay Summary</h3>
          
          {/* Dates */}
          <div className="flex items-start gap-4 mb-6 pb-6 border-b">
            <Calendar className="text-blue-500 flex-shrink-0 mt-1" size={20} />
            <div>
              <p className="text-gray-600 text-sm mb-3">Check-in & Check-out</p>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="font-semibold">{format(searchParams.checkInDate!, 'MMM dd, yyyy')}</p>
                  <p className="text-xs text-gray-600">Check-in from 2:00 PM</p>
                </div>
                <div>
                  <p className="font-semibold">{format(searchParams.checkOutDate!, 'MMM dd, yyyy')}</p>
                  <p className="text-xs text-gray-600">Check-out by 11:00 AM</p>
                </div>
              </div>
              <p className="text-sm text-gray-700 mt-3 font-semibold">
                Duration: {nights} night{nights > 1 ? 's' : ''}
              </p>
            </div>
          </div>

          {/* Guests */}
          <div className="flex items-start gap-4">
            <Users className="text-green-500 flex-shrink-0 mt-1" size={20} />
            <div>
              <p className="text-gray-600 text-sm mb-2">Guests</p>
              <p className="font-semibold">
                {searchParams.adults} Adult{searchParams.adults > 1 ? 's' : ''}
                {searchParams.children > 0 && ` + ${searchParams.children} Child${searchParams.children > 1 ? 'ren' : ''}`}
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Rooms Booked */}
      <Card>
        <CardContent className="p-8">
          <h3 className="font-bold text-lg mb-4">Rooms Booked</h3>
          <div className="space-y-3">
            {selectedRooms.map((room, idx) => (
              <div key={idx} className="flex justify-between items-center p-4 bg-gray-50 rounded-lg">
                <div>
                  <p className="font-semibold">{room.roomType}</p>
                  <p className="text-sm text-gray-600">
                    {room.quantity} room{room.quantity > 1 ? 's' : ''} × {nights} night{nights > 1 ? 's' : ''}
                  </p>
                </div>
                <div className="text-right">
                  <p className="font-bold text-lg">
                    ₹{room.totalPrice.toLocaleString('en-IN')}
                  </p>
                  <p className="text-xs text-gray-600">
                    ₹{room.pricePerNight.toLocaleString('en-IN')}/night
                  </p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Guest Information */}
      <Card>
        <CardContent className="p-8">
          <h3 className="font-bold text-lg mb-4">Guest Information</h3>
          <div className="space-y-4">
            <div>
              <p className="text-gray-600 text-sm">Name</p>
              <p className="font-semibold">{guestInfo.fullName}</p>
            </div>
            <div>
              <p className="text-gray-600 text-sm">Email</p>
              <p className="font-semibold">{guestInfo.email}</p>
            </div>
            <div>
              <p className="text-gray-600 text-sm">Phone</p>
              <p className="font-semibold">{guestInfo.phone}</p>
            </div>
            {guestInfo.gstNumber && (
              <div>
                <p className="text-gray-600 text-sm">GST Number</p>
                <p className="font-semibold">{guestInfo.gstNumber}</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Price Summary */}
      <Card className="border-2 border-green-200 bg-green-50">
        <CardContent className="p-8">
          <h3 className="font-bold text-lg mb-4">Total Amount Paid</h3>
          <div className="space-y-3">
            <div className="flex justify-between">
              <span className="text-gray-700">Room Charges ({nights} night{nights > 1 ? 's' : ''})</span>
              <span className="font-semibold">₹{pricing.subtotal.toLocaleString('en-IN')}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-700">Taxes & Charges (12% GST)</span>
              <span className="font-semibold">₹{pricing.taxAmount.toLocaleString('en-IN')}</span>
            </div>
            {pricing.discountAmount > 0 && (
              <div className="flex justify-between text-green-600">
                <span>Discount Applied</span>
                <span className="font-semibold">-₹{pricing.discountAmount.toLocaleString('en-IN')}</span>
              </div>
            )}
            <div className="border-t-2 border-green-300 pt-3 flex justify-between items-center">
              <span className="text-lg font-bold">Total Amount</span>
              <span className="text-3xl font-bold text-green-600">
                ₹{pricing.totalPrice.toLocaleString('en-IN')}
              </span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Important Information */}
      <Card className="bg-blue-50 border-blue-200">
        <CardContent className="p-6">
          <h3 className="font-bold text-blue-900 mb-4">Important Information</h3>
          <ul className="text-sm text-blue-900 space-y-2">
            <li className="flex gap-2">
              <span className="flex-shrink-0">✓</span>
              <span>Confirmation email has been sent to {guestInfo.email}</span>
            </li>
            <li className="flex gap-2">
              <span className="flex-shrink-0">✓</span>
              <span>A confirmation SMS has been sent to {guestInfo.phone}</span>
            </li>
            <li className="flex gap-2">
              <span className="flex-shrink-0">✓</span>
              <span>Keep your booking reference number for check-in</span>
            </li>
            <li className="flex gap-2">
              <span className="flex-shrink-0">✓</span>
              <span>Valid government-issued ID is required at check-in</span>
            </li>
            <li className="flex gap-2">
              <span className="flex-shrink-0">✓</span>
              <span>You can cancel up to 24 hours before check-in for a refund</span>
            </li>
          </ul>
        </CardContent>
      </Card>

      {/* Action Buttons */}
      <div className="flex flex-col gap-3">
        <Button
          onClick={handleDownloadReceipt}
          variant="outline"
          className="w-full flex items-center justify-center gap-2"
          size="lg"
        >
          <Download size={20} />
          Download Receipt
        </Button>
        
        <Button
          onClick={handleShareBooking}
          variant="outline"
          className="w-full flex items-center justify-center gap-2"
          size="lg"
        >
          <Share2 size={20} />
          Share Booking
        </Button>

        <Button
          onClick={() => navigate('/hotel-list')}
          className="w-full flex items-center justify-center gap-2"
          size="lg"
        >
          Continue Browsing
          <ArrowRight size={20} />
        </Button>
      </div>

      {/* Additional Help */}
      <Card>
        <CardContent className="p-6">
          <h3 className="font-bold mb-3">Need Help?</h3>
          <p className="text-sm text-gray-600 mb-4">
            If you have any questions or need to modify your booking, contact our support team.
          </p>
          <div className="flex gap-3">
            <Button variant="outline" size="sm" className="flex-1">
              📞 Call Support
            </Button>
            <Button variant="outline" size="sm" className="flex-1">
              💬 Live Chat
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default BookingConfirmation;
