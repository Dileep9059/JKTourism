import React, { useState, useEffect } from 'react';
import { format } from 'date-fns';
import { useHotelBooking } from '@/hooks/useHotelBooking';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { AlertCircle, Users, Plus, Minus } from 'lucide-react';
import axiosInstance from '@/axios/axios';

interface Room {
  roomId: string;
  roomType: string;
  capacity: number;
  pricePerNight: number;
  amenities: string[];
  images: string[];
  availableCount: number;
}

interface RoomSelectionProps {
  hotelId: string;
}

const RoomSelection: React.FC<RoomSelectionProps> = ({ hotelId }) => {
  const { searchParams, selectedRooms, addSelectedRoom, removeSelectedRoom, updateSelectedRoom, calculateNights } = useHotelBooking();
  const [rooms, setRooms] = useState<Room[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const nights = calculateNights();
  const totalGuestsNeeded = searchParams.adults + searchParams.children;

  // Fetch available rooms
  useEffect(() => {
    const fetchRooms = async () => {
      if (!searchParams.checkInDate || !searchParams.checkOutDate) {
        setError('Please select check-in and check-out dates');
        setLoading(false);
        return;
      }

      try {
        setLoading(true);
        const response = await axiosInstance.get(`/api/hotel/${hotelId}/rooms`, {
          params: {
            checkIn: format(searchParams.checkInDate, 'yyyy-MM-dd'),
            checkOut: format(searchParams.checkOutDate, 'yyyy-MM-dd'),
          },
        });
        setRooms(response.data);
        setError(null);
      } catch (err) {
        console.error('Error fetching rooms:', err);
        setError('Unable to load available rooms. Please try again.');
      } finally {
        setLoading(false);
      }
    };

    fetchRooms();
  }, [hotelId, searchParams.checkInDate, searchParams.checkOutDate]);

  // Handle room selection
  const handleRoomSelection = (room: Room, checked: boolean) => {
    if (checked) {
      addSelectedRoom({
        roomId: room.roomId,
        roomType: room.roomType,
        pricePerNight: room.pricePerNight,
        quantity: 1,
        amenities: room.amenities,
        images: room.images,
        numberOfNights: nights,
        totalPrice: room.pricePerNight * nights,
      });
    } else {
      removeSelectedRoom(room.roomId);
    }
  };

  // Update quantity
  const handleQuantityChange = (roomId: string, newQuantity: number) => {
    if (newQuantity <= 0) {
      removeSelectedRoom(roomId);
    } else {
      const room = rooms.find((r) => r.roomId === roomId);
      if (room && newQuantity <= room.availableCount) {
        updateSelectedRoom(roomId, {
          quantity: newQuantity,
          totalPrice: room.pricePerNight * nights * newQuantity,
        });
      }
    }
  };

  // Check if room is selected
  const isRoomSelected = (roomId: string): boolean => {
    return selectedRooms.some((r) => r.roomId === roomId);
  };

  // Get selected quantity
  const getSelectedQuantity = (roomId: string): number => {
    const room = selectedRooms.find((r) => r.roomId === roomId);
    return room?.quantity || 0;
  };

  // Calculate if this room type can accommodate guests
  const canAccommodateGuests = (room: Room): boolean => {
    const selectedQty = getSelectedQuantity(room.roomId);
    const totalCapacity = room.capacity * (selectedQty || 1);
    return totalCapacity >= totalGuestsNeeded;
  };

  // Calculate if guest count is met
  const isGuestCountMet = (): boolean => {
    let totalCapacity = 0;
    selectedRooms.forEach((room) => {
      const roomType = rooms.find((r) => r.roomId === room.roomId);
      if (roomType) {
        totalCapacity += roomType.capacity * room.quantity;
      }
    });
    return totalCapacity >= totalGuestsNeeded;
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex gap-3 p-4 bg-red-50 border border-red-200 rounded-lg">
        <AlertCircle className="text-red-600 flex-shrink-0" />
        <div>
          <p className="font-semibold text-red-900">{error}</p>
          <p className="text-sm text-red-700 mt-1">Please go back and select valid dates</p>
        </div>
      </div>
    );
  }

  if (rooms.length === 0) {
    return (
      <div className="text-center py-12">
        <AlertCircle size={48} className="mx-auto mb-4 text-orange-500" />
        <h3 className="text-lg font-semibold mb-2">No Rooms Available</h3>
        <p className="text-gray-600">
          Unfortunately, there are no available rooms for your selected dates.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-bold mb-2">Select Your Rooms</h2>
        <p className="text-gray-600">
          Check-in: {format(searchParams.checkInDate!, 'MMM dd, yyyy')} • 
          Check-out: {format(searchParams.checkOutDate!, 'MMM dd, yyyy')} • 
          {nights} night(s)
        </p>
        <p className="text-gray-600 mt-2">
          Guests: {searchParams.adults} adult(s)
          {searchParams.children > 0 && ` + ${searchParams.children} child(ren)`}
        </p>
      </div>

      {/* Guest Count Status */}
      {!isGuestCountMet() && (
        <div className="flex gap-3 p-4 bg-orange-50 border border-orange-200 rounded-lg">
          <AlertCircle className="text-orange-600 flex-shrink-0" />
          <div className="text-sm">
            <p className="font-semibold text-orange-900">Select more rooms</p>
            <p className="text-orange-700">
              The current selection doesn't have enough capacity for {totalGuestsNeeded} guest(s)
            </p>
          </div>
        </div>
      )}

      {/* Room Cards */}
      <div className="space-y-4">
        {rooms.map((room) => {
          const isSelected = isRoomSelected(room.roomId);
          const quantity = getSelectedQuantity(room.roomId);
          const totalPrice = room.pricePerNight * nights * quantity;

          return (
            <Card
              key={room.roomId}
              className={`overflow-hidden transition-all cursor-pointer ${
                isSelected ? 'ring-2 ring-blue-500 border-blue-500' : ''
              }`}
              onClick={() => handleRoomSelection(room, !isSelected)}
            >
              <CardContent className="p-6">
                <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                  {/* Image */}
                  <div className="md:col-span-1">
                    <img
                      src={room.images[0] || `${import.meta.env.VITE_BASE}assets/images/hotel-booking/room.jpeg`}
                      alt={room.roomType}
                      className="w-full h-40 object-cover rounded-lg"
                      onError={(e) => {
                        (e.target as HTMLImageElement).src =
                          `${import.meta.env.VITE_BASE}assets/images/hotel-booking/room.jpeg`;
                      }}
                    />
                  </div>

                  {/* Details */}
                  <div className="md:col-span-2 space-y-3">
                    <div className="flex items-start justify-between">
                      <div>
                        <h3 className="text-xl font-bold">{room.roomType}</h3>
                        <div className="flex items-center gap-2 mt-2">
                          <Users size={16} className="text-gray-600" />
                          <span className="text-sm text-gray-600">
                            Capacity: {room.capacity} person{room.capacity > 1 ? 's' : ''}
                          </span>
                        </div>
                      </div>
                      <Checkbox
                        checked={isSelected}
                        onClick={(e) => e.stopPropagation()}
                        onChange={(checked) => {
                          e.stopPropagation();
                          handleRoomSelection(room, checked);
                        }}
                      />
                    </div>

                    {/* Amenities */}
                    <div>
                      <p className="text-sm font-semibold mb-2">Amenities:</p>
                      <div className="flex flex-wrap gap-2">
                        {room.amenities.slice(0, 3).map((amenity, idx) => (
                          <Badge key={idx} variant="secondary" className="text-xs">
                            {amenity}
                          </Badge>
                        ))}
                        {room.amenities.length > 3 && (
                          <Badge variant="secondary" className="text-xs">
                            +{room.amenities.length - 3} more
                          </Badge>
                        )}
                      </div>
                    </div>

                    {/* Availability */}
                    <p className={`text-sm font-semibold ${
                      room.availableCount <= 3 ? 'text-orange-600' : 'text-green-600'
                    }`}>
                      {room.availableCount} room{room.availableCount !== 1 ? 's' : ''} available
                    </p>
                  </div>

                  {/* Selection & Price */}
                  <div className="md:col-span-1 flex flex-col justify-between">
                    {/* Price */}
                    <div className="text-right mb-4">
                      <p className="text-gray-600 text-sm">₹{room.pricePerNight.toLocaleString('en-IN')}/night</p>
                      <p className="text-gray-600 text-xs mt-1">{nights} night(s)</p>
                      {isSelected && (
                        <>
                          <p className="text-xl font-bold mt-2 text-blue-600">
                            ₹{totalPrice.toLocaleString('en-IN')}
                          </p>
                          <p className="text-xs text-gray-500">Total for {quantity} room(s)</p>
                        </>
                      )}
                    </div>

                    {/* Quantity Control */}
                    {isSelected && (
                      <div className="flex items-center gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleQuantityChange(room.roomId, quantity - 1);
                          }}
                          disabled={quantity <= 1}
                        >
                          <Minus size={16} />
                        </Button>
                        <span className="w-8 text-center font-semibold">{quantity}</span>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleQuantityChange(room.roomId, quantity + 1);
                          }}
                          disabled={quantity >= room.availableCount}
                        >
                          <Plus size={16} />
                        </Button>
                      </div>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Summary */}
      {selectedRooms.length > 0 && (
        <Card className="bg-blue-50 border-blue-200">
          <CardContent className="p-6">
            <h3 className="font-bold mb-3">Selected Rooms</h3>
            <div className="space-y-2">
              {selectedRooms.map((room) => (
                <div key={room.roomId} className="flex justify-between text-sm">
                  <span>
                    {room.quantity}x {room.roomType}
                    {room.quantity > 1 && 's'}
                  </span>
                  <span className="font-semibold">
                    ₹{room.totalPrice.toLocaleString('en-IN')}
                  </span>
                </div>
              ))}
            </div>
            <div className="border-t my-3"></div>
            <div className="flex justify-between font-bold text-lg">
              <span>Subtotal (before tax):</span>
              <span className="text-blue-600">
                ₹{selectedRooms
                  .reduce((sum, room) => sum + room.totalPrice, 0)
                  .toLocaleString('en-IN')}
              </span>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Guest Accommodation Status */}
      {selectedRooms.length > 0 && isGuestCountMet() && (
        <Card className="bg-green-50 border-green-200">
          <CardContent className="p-4">
            <p className="text-sm text-green-700 font-semibold">
              ✓ Selected rooms have sufficient capacity for {totalGuestsNeeded} guest(s)
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default RoomSelection;
