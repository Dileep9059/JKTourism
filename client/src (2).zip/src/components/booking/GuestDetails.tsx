import React, { useState } from 'react';
import { useHotelBooking } from '@/hooks/useHotelBooking';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import { AlertCircle, Mail, Phone, User } from 'lucide-react';

const GuestDetails: React.FC = () => {
  const { guestInfo, setGuestInfo } = useHotelBooking();
  const [errors, setErrors] = useState<{ [key: string]: string }>({});

  // Validate email
  const isValidEmail = (email: string): boolean => {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  };

  // Validate phone
  const isValidPhone = (phone: string): boolean => {
    return /^[\d\s\-\+\(\)]{10,}$/.test(phone);
  };

  // Handle input change
  const handleChange = (field: string, value: string) => {
    setGuestInfo({ [field]: value });

    // Clear error for this field
    if (errors[field]) {
      setErrors((prev) => {
        const newErrors = { ...prev };
        delete newErrors[field];
        return newErrors;
      });
    }
  };

  // Handle blur validation
  const handleBlur = (field: string) => {
    const newErrors = { ...errors };

    switch (field) {
      case 'fullName':
        if (!guestInfo.fullName.trim()) {
          newErrors.fullName = 'Full name is required';
        } else if (guestInfo.fullName.length < 2) {
          newErrors.fullName = 'Name must be at least 2 characters';
        }
        break;

      case 'email':
        if (!guestInfo.email.trim()) {
          newErrors.email = 'Email is required';
        } else if (!isValidEmail(guestInfo.email)) {
          newErrors.email = 'Please enter a valid email address';
        }
        break;

      case 'phone':
        if (!guestInfo.phone.trim()) {
          newErrors.phone = 'Phone number is required';
        } else if (!isValidPhone(guestInfo.phone)) {
          newErrors.phone = 'Please enter a valid phone number';
        }
        break;

      case 'gstNumber':
        if (guestInfo.gstNumber && guestInfo.gstNumber.length > 0) {
          if (!/^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/.test(guestInfo.gstNumber)) {
            newErrors.gstNumber = 'Please enter a valid GST number';
          }
        }
        break;

      default:
        break;
    }

    setErrors(newErrors);
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-bold mb-2">Guest Information</h2>
        <p className="text-gray-600">Please provide your details for the booking</p>
      </div>

      {/* Main Details */}
      <Card>
        <CardContent className="p-8">
          <div className="space-y-6">
            {/* Full Name */}
            <div className="space-y-2">
              <Label htmlFor="fullName" className="font-semibold flex items-center gap-2">
                <User size={18} className="text-gray-600" />
                Full Name *
              </Label>
              <Input
                id="fullName"
                placeholder="Enter your full name"
                value={guestInfo.fullName}
                onChange={(e) => handleChange('fullName', e.target.value)}
                onBlur={() => handleBlur('fullName')}
                className={errors.fullName ? 'border-red-500' : ''}
              />
              {errors.fullName && (
                <p className="text-sm text-red-600 flex items-center gap-1">
                  <AlertCircle size={14} />
                  {errors.fullName}
                </p>
              )}
            </div>

            {/* Email */}
            <div className="space-y-2">
              <Label htmlFor="email" className="font-semibold flex items-center gap-2">
                <Mail size={18} className="text-gray-600" />
                Email Address *
              </Label>
              <Input
                id="email"
                type="email"
                placeholder="your.email@example.com"
                value={guestInfo.email}
                onChange={(e) => handleChange('email', e.target.value)}
                onBlur={() => handleBlur('email')}
                className={errors.email ? 'border-red-500' : ''}
              />
              {errors.email && (
                <p className="text-sm text-red-600 flex items-center gap-1">
                  <AlertCircle size={14} />
                  {errors.email}
                </p>
              )}
              <p className="text-xs text-gray-500">
                Booking confirmation will be sent to this email
              </p>
            </div>

            {/* Phone */}
            <div className="space-y-2">
              <Label htmlFor="phone" className="font-semibold flex items-center gap-2">
                <Phone size={18} className="text-gray-600" />
                Phone Number *
              </Label>
              <Input
                id="phone"
                type="tel"
                placeholder="+91 9876543210"
                value={guestInfo.phone}
                onChange={(e) => handleChange('phone', e.target.value)}
                onBlur={() => handleBlur('phone')}
                className={errors.phone ? 'border-red-500' : ''}
              />
              {errors.phone && (
                <p className="text-sm text-red-600 flex items-center gap-1">
                  <AlertCircle size={14} />
                  {errors.phone}
                </p>
              )}
              <p className="text-xs text-gray-500">
                We'll use this to send you booking updates via SMS
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* GST Section */}
      <Card>
        <CardContent className="p-8">
          <div className="space-y-4">
            <h3 className="font-bold text-lg">GST Information (Optional)</h3>
            <p className="text-sm text-gray-600">
              Provide GST details if you're an Indian resident or business for tax benefits
            </p>

            <div className="space-y-2">
              <Label htmlFor="gstNumber" className="font-semibold">
                GST Number
              </Label>
              <Input
                id="gstNumber"
                placeholder="22AABCT1234H1Z0"
                value={guestInfo.gstNumber || ''}
                onChange={(e) => handleChange('gstNumber', e.target.value)}
                onBlur={() => handleBlur('gstNumber')}
                className={errors.gstNumber ? 'border-red-500' : ''}
              />
              {errors.gstNumber && (
                <p className="text-sm text-red-600 flex items-center gap-1">
                  <AlertCircle size={14} />
                  {errors.gstNumber}
                </p>
              )}
              <p className="text-xs text-gray-500">
                Format: 2 digits + 5 uppercase letters + 4 digits + letter + digit/letter + Z + alphanumeric
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Special Requests */}
      <Card>
        <CardContent className="p-8">
          <div className="space-y-4">
            <h3 className="font-bold text-lg">Special Requests (Optional)</h3>
            <p className="text-sm text-gray-600">
              Let the hotel know about any special preferences or requirements
            </p>

            <Textarea
              placeholder="E.g., High floor preference, late check-in, extra pillows, dietary restrictions, anniversary celebration, etc."
              value={guestInfo.specialRequests || ''}
              onChange={(e) => handleChange('specialRequests', e.target.value)}
              className="min-h-32 resize-none"
            />
            <p className="text-xs text-gray-500">
              {(guestInfo.specialRequests || '').length}/500 characters
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Important Notes */}
      <Card className="bg-blue-50 border-blue-200">
        <CardContent className="p-6 space-y-3">
          <h3 className="font-bold text-blue-900 flex items-center gap-2">
            <AlertCircle size={20} className="text-blue-600" />
            Important Notes
          </h3>
          <ul className="text-sm text-blue-900 space-y-2">
            <li className="flex gap-2">
              <span className="flex-shrink-0">•</span>
              <span>Ensure all details are correct before proceeding to payment</span>
            </li>
            <li className="flex gap-2">
              <span className="flex-shrink-0">•</span>
              <span>A valid government-issued ID is required at check-in</span>
            </li>
            <li className="flex gap-2">
              <span className="flex-shrink-0">•</span>
              <span>You will receive a confirmation SMS and email with booking details</span>
            </li>
            <li className="flex gap-2">
              <span className="flex-shrink-0">•</span>
              <span>Cancellation policy will be clearly displayed in the confirmation</span>
            </li>
          </ul>
        </CardContent>
      </Card>

      {/* Terms & Conditions */}
      <Card>
        <CardContent className="p-6">
          <div className="flex gap-3">
            <Checkbox id="terms" className="mt-1" />
            <Label htmlFor="terms" className="cursor-pointer text-sm">
              I agree to the <a href="#" className="text-blue-600 hover:underline">Terms and Conditions</a> and <a href="#" className="text-blue-600 hover:underline">Privacy Policy</a>. I also acknowledge the <a href="#" className="text-blue-600 hover:underline">cancellation policy</a> of the hotel.
            </Label>
          </div>
        </CardContent>
      </Card>

      {/* Status Message */}
      <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
        <p className="text-sm text-green-700 font-semibold">
          ✓ All required fields are {
            guestInfo.fullName.trim() &&
            guestInfo.email.trim() &&
            isValidEmail(guestInfo.email) &&
            guestInfo.phone.trim() &&
            isValidPhone(guestInfo.phone)
              ? 'complete'
              : 'incomplete'
          }
        </p>
      </div>
    </div>
  );
};

export default GuestDetails;
