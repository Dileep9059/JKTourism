import { useEffect, useRef, useState, useCallback } from 'react'
import scss from './hotellist.module.scss';
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { format } from "date-fns";
import {
  ArrowDown, Calendar as CalendarIcon, ChevronDown, ChevronUp,
  MapPin, Minus, Plus, Star, Building2, Loader2
} from "lucide-react";
import type { DateRange } from "react-day-picker";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from '@radix-ui/react-popover';
import clsx from 'clsx';
import { FaChevronLeft, FaChevronRight } from 'react-icons/fa';
import { Swiper, SwiperSlide } from "swiper/react";
import { FreeMode, Navigation } from "swiper/modules";
import "swiper/css";
import "swiper/css/free-mode";
import "swiper/css/navigation";
import axiosInstance from '@/axios/axios';
// 🆕 ADD THESE IMPORTS
import { useHotelBooking } from '@/hooks/useHotelBooking';
import { Dialog, DialogContent, DialogClose } from "@/components/ui/dialog";
import HotelDetailModal from '@/components/hoteldetail/HotelDetailModal';

// ── Types ──────────────────────────────────────────────────────────────────────

interface Hotel {
  id: string;
  displayName: string;
  legalName: string;
  city: string;
  district: string;
  state: string;
  landmark: string | null;
  description: string | null;
  starRating: number | null;
  hotelType: string | null;
  minTariff: number | null;
  roomTypeName: string | null;
  coverPhotoUrl: string | null;
}

interface HotelPage {
  content: Hotel[];
  totalElements: number;
  totalPages: number;
  number: number;
}

// Only Jammu and Kashmir as requested
const DISTRICTS = ["Jammu", "Kashmir"];

// ── Component ──────────────────────────────────────────────────────────────────

function Hotellist() {
  // 🆕 FIX DATE INITIALIZATION - USE TODAY'S DATE INSTEAD OF 2026
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const defaultCheckOut = new Date(today);
  defaultCheckOut.setDate(defaultCheckOut.getDate() + 2); // 2 nights default

  const [dateRange, setDateRange] = useState<DateRange | undefined>({
    from: today,
    to: defaultCheckOut,
  });

  const [childrenCount, setChildrenCount] = useState(0);
  const [childrenAges, setChildrenAges] = useState<number[]>([]);
  const [isChildOpen, setIsChildOpen] = useState(false);

  // ── Search filter state (what user selected in UI) ────────────────────────
  const [selectedDistrict, setSelectedDistrict] = useState<string>('all');
  const [selectedStarRating, setSelectedStarRating] = useState<string>('all');
  const [selectedRoomType, setSelectedRoomType] = useState<string>('all');

  // ── Applied filter state (what was last searched) ─────────────────────────
  const [appliedDistrict, setAppliedDistrict] = useState<string>('all');
  const [appliedStarRating, setAppliedStarRating] = useState<string>('all');
  const [appliedRoomType, setAppliedRoomType] = useState<string>('all');

  // ── Hotel list state ──────────────────────────────────────────────────────
  const [hotelList, setHotelList] = useState<Hotel[]>([]);
  const [totalElements, setTotalElements] = useState(0);
  const [currentPage, setCurrentPage] = useState(0);
  const [totalPages, setTotalPages] = useState(0);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [selectedSort, setSelectedSort] = useState<string>('Popularity');

  // ── Sidebar filter state ──────────────────────────────────────────────────
  const [selectedFilters, setSelectedFilters] = useState<number[]>([]);
  const [expandedLists, setExpandedLists] = useState<Record<string, boolean>>({
    suggested: false,
    facility: false,
  });

  // 🆕 ADD MODAL AND AVAILABILITY STATES
  const [selectedHotelForModal, setSelectedHotelForModal] = useState<Hotel | null>(null);
  const [hotelAvailability, setHotelAvailability] = useState<{
    [key: string]: { available: boolean; availableRooms: number };
  }>({});
  const { setSearchParams } = useHotelBooking();

  const swiperRef = useRef<any>(null);

  // ── Helpers ───────────────────────────────────────────────────────────────
  const handleIncrement = () => {
    setChildrenCount(p => p + 1);
    setChildrenAges(p => [...p, 0]);
  };
  const handleDecrement = () => {
    if (childrenCount > 0) {
      setChildrenCount(p => p - 1);
      setChildrenAges(p => p.slice(0, -1));
    }
  };
  const handleAgeChange = (index: number, value: number) => {
    const ages = [...childrenAges];
    ages[index] = value;
    setChildrenAges(ages);
  };
  const toggleFilter = (id: number) =>
    setSelectedFilters(p => p.includes(id) ? p.filter(i => i !== id) : [...p, id]);
  const toggleList = (name: string) =>
    setExpandedLists(p => ({ ...p, [name]: !p[name] }));

  // 🆕 ADD HELPER FUNCTION TO DISABLE PAST DATES
  const isDateDisabled = (date: Date): boolean => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    return date < today;
  };

  // 🆕 ADD FUNCTION TO CHECK HOTEL AVAILABILITY
  const checkHotelAvailability = useCallback(async (hotelId: string) => {
    if (!dateRange?.from || !dateRange?.to) return;

    try {
      const response = await axiosInstance.get(
        `/api/hotel/${hotelId}/availability`,
        {
          params: {
            checkIn: format(dateRange.from, 'yyyy-MM-dd'),
            checkOut: format(dateRange.to, 'yyyy-MM-dd'),
          },
        }
      );

      setHotelAvailability((prev) => ({
        ...prev,
        [hotelId]: {
          available: response.data.available,
          availableRooms: response.data.availableRooms || 0,
        },
      }));
    } catch (error) {
      console.error(`Error checking availability for hotel ${hotelId}:`, error);
      // Assume available if API fails
      setHotelAvailability((prev) => ({
        ...prev,
        [hotelId]: { available: true, availableRooms: 5 },
      }));
    }
  }, [dateRange]);

  // 🆕 ADD FUNCTION TO HANDLE HOTEL CARD CLICK
  const handleHotelCardClick = (hotel: Hotel) => {
    // Save search parameters to context
    setSearchParams({
      checkInDate: dateRange?.from,
      checkOutDate: dateRange?.to,
      rooms: 1, // Default value - adjust as needed
      adults: 1, // Default value - adjust as needed
      children: childrenCount,
      childrenAges,
      district: appliedDistrict,
      roomType: appliedRoomType,
      starRating: appliedStarRating,
    });

    // Open modal with selected hotel
    setSelectedHotelForModal(hotel);
  };

  // ── API call ──────────────────────────────────────────────────────────────
  const fetchHotelList = useCallback(async (page = 0) => {
    setLoading(true);
    setError(null);
    try {
      const payload: Record<string, any> = { page, size: 10 };
      if (appliedDistrict !== 'all')   payload.district   = appliedDistrict;
      if (appliedStarRating !== 'all') payload.starRating = Number(appliedStarRating);

      const response = await axiosInstance.post('/api/v1/hotels/hotellist', payload, {
        headers: { 'Content-Type': 'application/json' },
      });

      const data: HotelPage = response.data;
      setHotelList(data.content);
      setTotalElements(data.totalElements);
      setTotalPages(data.totalPages);
      setCurrentPage(data.number);
    } catch (err: any) {
      setError('Failed to load hotels. Please try again.');
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, [appliedDistrict, appliedStarRating]);

  // Direct fetch with explicit filters — avoids stale state timing issues
  const fetchHotelListWithFilters = async (page = 0, district: string, starRating: string, roomType: string) => {
    setLoading(true);
    setError(null);
    try {
      const payload: Record<string, any> = { page, size: 10 };
      if (district !== 'all')   payload.district   = district;
      if (starRating !== 'all') payload.starRating = Number(starRating);
      if (roomType !== 'all')   payload.roomType   = roomType;

      const response = await axiosInstance.post('/api/v1/hotels/hotellist', payload, {
        headers: { 'Content-Type': 'application/json' },
      });

      const data: HotelPage = response.data;
      setHotelList(data.content);
      setTotalElements(data.totalElements);
      setTotalPages(data.totalPages);
      setCurrentPage(data.number);
    } catch (err: any) {
      setError('Failed to load hotels. Please try again.');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  // 🆕 ADD useEffect HOOKS
  useEffect(() => {
    fetchHotelList(0);
  }, []);

  // 🆕 CHECK AVAILABILITY WHEN HOTELS LOAD
  useEffect(() => {
    hotelList.forEach((hotel) => {
      checkHotelAvailability(hotel.id);
    });
  }, [hotelList, dateRange, checkHotelAvailability]);

  // 🆕 AUTO-TRIGGER SEARCH WHEN STAR RATING CHANGES
  useEffect(() => {
    if (selectedStarRating !== '') {
      setAppliedStarRating(selectedStarRating);
      const timer = setTimeout(() => {
        fetchHotelList(0);
      }, 300);
      return () => clearTimeout(timer);
    }
  }, [selectedStarRating]);

  const handleSearch = () => {
    setAppliedDistrict(selectedDistrict);
    setAppliedStarRating(selectedStarRating);
    setAppliedRoomType(selectedRoomType);
    setCurrentPage(0);
    fetchHotelListWithFilters(0, selectedDistrict, selectedStarRating, selectedRoomType);
  };

  // ── Star icons helper ─────────────────────────────────────────────────────
  const renderStars = (count: number | null) => {
    if (!count) return null;
    return (
      <span className="flex gap-0.5">
        {Array.from({ length: count }, (_, i) => (
          <Star
            key={i}
            size={16}
            className="fill-yellow-400 text-yellow-400"
          />
        ))}
      </span>
    );
  };

  // ── Photo URL helper ──────────────────────────────────────────────────────
  const getPhotoUrl = (url: string | null): string =>
    url && url.startsWith('http') ? url : `${import.meta.env.VITE_BASE}assets/images/hotel-booking/gallery-1.jpeg`;

  // ── Sorting ───────────────────────────────────────────────────────────────
  const getSortedHotels = (hotels: Hotel[]): Hotel[] => {
    const sorted = [...hotels];
    switch (selectedSort) {
      case 'Price (Low to High)':
        return sorted.sort((a, b) => (a.minTariff || 0) - (b.minTariff || 0));
      case 'Price (High to Low)':
        return sorted.sort((a, b) => (b.minTariff || 0) - (a.minTariff || 0));
      case 'User Rating (Highest)':
        return sorted.sort((a, b) => (b.starRating || 0) - (a.starRating || 0));
      default:
        return sorted;
    }
  };

  const roomCount = 1; // Placeholder — connect to actual UI if needed
  const adultsCount = 1; // Placeholder
  const roomType = 'all';

  return (
    <>
      <div className={scss.container}>
        {/* HEADER */}
        <div className={scss.header_search}>
          <p className={scss.header_title}>Find Your Perfect Hotel</p>
        </div>

        {/* MAIN CONTENT */}
        <section className={scss.search_container}>
          <div className={scss.hotel_list_wrapper}>
            {/* FILTER SIDEBAR */}
            <aside className={scss.filter_sidebar}>
              <div className={scss.filter_section}>
                {/* District Filter */}
                <div className={scss.filter_group}>
                  <div className={scss.filter_title}>
                    <span>District</span>
                    <ChevronDown size={18} />
                  </div>
                  <Select value={selectedDistrict} onValueChange={setSelectedDistrict}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectGroup>
                        <SelectItem value="all">All Districts</SelectItem>
                        {DISTRICTS.map(d => (
                          <SelectItem key={d} value={d}>{d}</SelectItem>
                        ))}
                      </SelectGroup>
                    </SelectContent>
                  </Select>
                </div>

                {/* Room Type Filter */}
                <div className={scss.filter_group}>
                  <div className={scss.filter_title}>
                    <span>Room Type</span>
                    <ChevronDown size={18} />
                  </div>
                  <Select value={selectedRoomType} onValueChange={setSelectedRoomType}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectGroup>
                        <SelectItem value="all">All Room Types</SelectItem>
                        <SelectItem value="single">Single</SelectItem>
                        <SelectItem value="double">Double</SelectItem>
                        <SelectItem value="suite">Suite</SelectItem>
                      </SelectGroup>
                    </SelectContent>
                  </Select>
                </div>

                {/* Check-in / Check-out */}
                <div className={scss.filter_group}>
                  <div className={scss.filter_title}>
                    <CalendarIcon size={18} />
                    <span>Dates</span>
                  </div>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button variant="outline" className="w-full justify-start">
                        {dateRange?.from ? format(dateRange.from, 'MMM dd') : 'From'} -{' '}
                        {dateRange?.to ? format(dateRange.to, 'MMM dd') : 'To'}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent side="bottom" align="start">
                      {/* 🆕 ADD disabled PROP TO CALENDAR */}
                      <Calendar
                        disabled={isDateDisabled}
                        mode="range"
                        defaultMonth={today}
                        selected={dateRange}
                        onSelect={setDateRange}
                      />
                    </PopoverContent>
                  </Popover>
                </div>

                {/* Guests */}
                <div className={scss.filter_group}>
                  <div className={scss.filter_title}>
                    <span>Adults</span>
                  </div>
                  <RadioGroup defaultValue="1">
                    {[1, 2, 3].map(n => (
                      <div key={n} className="flex items-center gap-2">
                        <RadioGroupItem value={String(n)} id={`adult-${n}`} />
                        <label htmlFor={`adult-${n}`} className="text-sm cursor-pointer">{n}</label>
                      </div>
                    ))}
                  </RadioGroup>
                </div>

                {/* Children */}
                <div className={scss.filter_group}>
                  <div className={scss.filter_title} onClick={() => setIsChildOpen(!isChildOpen)}>
                    <span>Children ({childrenCount})</span>
                    {isChildOpen ? <ChevronUp size={18} /> : <ChevronDown size={18} />}
                  </div>
                  {isChildOpen && (
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-sm">Add Children</span>
                        <div className="flex gap-2">
                          <Button size="sm" variant="outline" onClick={handleDecrement}>
                            <Minus size={16} />
                          </Button>
                          <span className="px-3 py-1">{childrenCount}</span>
                          <Button size="sm" variant="outline" onClick={handleIncrement}>
                            <Plus size={16} />
                          </Button>
                        </div>
                      </div>
                      {childrenAges.map((age, i) => (
                        <div key={i} className="flex items-center gap-2">
                          <label className="text-sm">Child {i + 1} Age</label>
                          <input
                            type="number"
                            min="0"
                            max="17"
                            value={age}
                            onChange={(e) => handleAgeChange(i, Number(e.target.value))}
                            className="w-20 px-2 py-1 border rounded text-sm"
                          />
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* Star Rating Filter */}
                <div className={scss.filter_group}>
                  <div className={scss.filter_title}>
                    <span>Star Rating</span>
                    <ChevronDown size={18} />
                  </div>
                  <Select value={selectedStarRating} onValueChange={setSelectedStarRating}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectGroup>
                        <SelectItem value="all">All Ratings</SelectItem>
                        <SelectItem value="5">⭐⭐⭐⭐⭐ 5 Stars</SelectItem>
                        <SelectItem value="4">⭐⭐⭐⭐ 4 Stars</SelectItem>
                        <SelectItem value="3">⭐⭐⭐ 3 Stars</SelectItem>
                        <SelectItem value="2">⭐⭐ 2 Stars</SelectItem>
                        <SelectItem value="1">⭐ 1 Star</SelectItem>
                      </SelectGroup>
                    </SelectContent>
                  </Select>
                </div>

                {/* Search Button */}
                <Button onClick={handleSearch} className="w-full">
                  Search Hotels
                </Button>
              </div>
            </aside>

            {/* MAIN CONTENT AREA */}
            <div className={scss.main_content}>
              <div className={scss.hotels_section}>

                {/* Sorting Slider */}
                <div className={scss.sort_section}>
                  <button
                    onClick={() => swiperRef.current?.swiper.slidePrev()}
                    className={clsx(scss.prev_btn, 'swiper-button-prev rounded-full bg-white p-2 shadow-md')}
                  >
                    <FaChevronLeft />
                  </button>
                  <div className={scss.filter_slider_wrapper}>
                    <Swiper
                      ref={swiperRef}
                      slidesPerView={3}
                      spaceBetween={20}
                      freeMode
                      modules={[FreeMode, Navigation]}
                      navigation={{ nextEl: '.swiper-button-next', prevEl: '.swiper-button-prev' }}
                      className="mySwiper"
                    >
                      {['Popularity', 'Price (Low to High)', 'User Rating (Highest)', 'Lowest Price & Best Rated', 'Price (High to Low)'].map(label => (
                        <SwiperSlide key={label}>
                          <div
                            className={scss.filter_btn}
                            onClick={() => setSelectedSort(label)}
                            style={{ cursor: 'pointer' }}
                          >
                            <input
                              type="radio"
                              id={label}
                              name="sort-filter"
                              checked={selectedSort === label}
                              onChange={() => setSelectedSort(label)}
                            />
                            <label htmlFor={label} style={{ cursor: 'pointer' }}>{label}</label>
                          </div>
                        </SwiperSlide>
                      ))}
                    </Swiper>
                  </div>
                  <button
                    onClick={() => swiperRef.current?.swiper.slideNext()}
                    className={clsx(scss.next_btn, 'swiper-button-next rounded-full bg-white p-2 shadow-md')}
                  >
                    <FaChevronRight />
                  </button>
                </div>

                {/* Result count heading */}
                <h4 className={scss.result_head}>
                  {appliedDistrict !== 'all' ? `${appliedDistrict} : ` : ''}
                  {totalElements} Result{totalElements !== 1 ? 's' : ''} found
                </h4>

                {/* Loading */}
                {loading && (
                  <div className="flex items-center justify-center py-16 gap-3 text-muted-foreground">
                    <Loader2 className="animate-spin" size={24} />
                    <span>Loading hotels...</span>
                  </div>
                )}

                {/* Error */}
                {!loading && error && (
                  <div className="py-10 text-center text-red-500">{error}</div>
                )}

                {/* Empty */}
                {!loading && !error && hotelList.length === 0 && (
                  <div className="py-16 text-center text-muted-foreground">
                    <Building2 size={48} className="mx-auto mb-3 opacity-30" />
                    <p>No approved hotels found for your search.</p>
                    <p className="text-sm mt-1">Try selecting a different district or star rating.</p>
                  </div>
                )}

                {/* Hotel cards */}
                {!loading && !error && hotelList.length > 0 && (
                  <div className={scss.hotel_card_wrapper}>
                    {getSortedHotels(hotelList).map(hotel => (
                      <div
                        key={hotel.id}
                        className={scss.hotel_card}
                        style={{ cursor: 'pointer' }}
                        onClick={() => handleHotelCardClick(hotel)}
                      >

                        {/* Photo */}
                        <div className={scss.gallery} style={{ minWidth: '280px', maxWidth: '280px' }}>
                          <div className={scss.main_slider} style={{ height: '200px', width: '280px' }}>
                            <img
                              src={getPhotoUrl(hotel.coverPhotoUrl)}
                              alt={hotel.displayName || hotel.legalName}
                              style={{ height: '200px', width: '280px', objectFit: 'cover', borderRadius: '6px' }}
                              onError={e => {
                                (e.target as HTMLImageElement).src =
                                  `${import.meta.env.VITE_BASE}assets/images/hotel-booking/gallery-1.jpeg`;
                              }}
                            />
                          </div>
                        </div>

                        {/* Card content */}
                        <div className={scss.card_content}>
                          <div className={scss.card_head}>
                            <div className="flex items-center gap-2 flex-wrap">
                              <h4 className={scss.hotel_name}>
                                {hotel.displayName || hotel.legalName}
                              </h4>
                              {renderStars(hotel.starRating)}
                            </div>
                            <ul className={scss.facility_list}>
                              <li>
                                <MapPin />
                                <span>
                                  {[hotel.city, hotel.district, hotel.state].filter(Boolean).join(', ')}
                                  {hotel.landmark ? ` — ${hotel.landmark}` : ''}
                                </span>
                              </li>
                              {hotel.hotelType && (
                                <li><Building2 /><span>{hotel.hotelType}</span></li>
                              )}
                              {hotel.description && (
                                <li>
                                  <span className="text-muted-foreground text-sm line-clamp-2">
                                    {hotel.description}
                                  </span>
                                </li>
                              )}
                            </ul>
                          </div>

                          <div className={scss.card_footer}>
                            <div className={scss.detail_block}>
                              <p className="text-muted">
                                {hotel.hotelType
                                  ? `${hotel.hotelType} · ${hotel.district}, ${hotel.state}`
                                  : `${hotel.district}, ${hotel.state}`}
                              </p>
                              <p>{hotel.roomTypeName || 'Standard rooms'}</p>
                              <div className={scss.review_detail}>
                                <h5>Very Good ,</h5>
                                <span>Reviews</span>
                              </div>
                            </div>
                            {/* 🆕 UPDATE PRICE BLOCK WITH AVAILABILITY CHECK */}
                            <div className={scss.price_block}>
                              {hotelAvailability[hotel.id]?.available === false ? (
                                <Button disabled className="w-full bg-gray-400">
                                  Sold Out
                                </Button>
                              ) : (
                                <>
                                  {hotel.minTariff != null ? (
                                    <>
                                      <h5>₹{hotel.minTariff.toLocaleString('en-IN')}/-</h5>
                                      <p>Includes taxes and charges</p>
                                    </>
                                  ) : (
                                    <p className="text-muted-foreground text-sm">Price on request</p>
                                  )}
                                  <Button className="w-full mt-2">Book Now</Button>
                                </>
                              )}
                            </div>
                          </div>
                        </div>

                      </div>
                    ))}
                  </div>
                )}

                {/* Pagination */}
                {totalPages > 1 && !loading && (
                  <div className="flex items-center justify-center gap-3 mt-6 pb-4">
                    <Button
                      variant="outline"
                      size="sm"
                      disabled={currentPage === 0}
                      onClick={() => fetchHotelList(currentPage - 1)}
                    >
                      Previous
                    </Button>
                    <span className="text-sm text-muted-foreground">
                      Page {currentPage + 1} of {totalPages}
                    </span>
                    <Button
                      variant="outline"
                      size="sm"
                      disabled={currentPage >= totalPages - 1}
                      onClick={() => fetchHotelList(currentPage + 1)}
                    >
                      Next
                    </Button>
                  </div>
                )}

                {/* 🆕 ADD MODAL DIALOG */}
                <Dialog open={!!selectedHotelForModal} onOpenChange={(open) => {
                  if (!open) setSelectedHotelForModal(null);
                }}>
                  <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
                    <DialogClose />
                    {selectedHotelForModal && (
                      <HotelDetailModal 
                        hotel={selectedHotelForModal}
                        onClose={() => setSelectedHotelForModal(null)}
                      />
                    )}
                  </DialogContent>
                </Dialog>

              </div>
            </div>
          </div>
        </section>

      </div>
    </>
  );
}

export default Hotellist;
